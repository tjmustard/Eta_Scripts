#!/bin/bash
nPersistantOTS.py -i H2O.com -o H2O.log -n H2O -d `pwd` -t G09 -j OPT -p /share/apps/Gaussian -T
