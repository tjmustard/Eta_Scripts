#!/bin/bash
rm -rfv SCRATCH-*
cp BACKUP/* .
