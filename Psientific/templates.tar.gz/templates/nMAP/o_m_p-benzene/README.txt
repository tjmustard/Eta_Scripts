To make all the xyz files compatible with the nMAP.py script I ran nTranslate-XYZ-Renumber.py to match the majority of the atom numberings.
